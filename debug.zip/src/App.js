import React from "react";
import logo from "./images/logo.png";
import banner from "./images/banner.png";
import "./App.css";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Container from "@material-ui/core/Container";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import { withStyles } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import Box from "@material-ui/core/Box";
import TextField from "@material-ui/core/TextField";
import InputAdornment from "@material-ui/core/InputAdornment";
import img1 from "./images/sequoia.png";
import img2 from "./images/polychain_capital.png";
import img3 from "./images/consensys.png";
import bonus from "./images/juno-apy-215.svg";
import flag from "./images/flag.png";
import Card from "./components/Card";
import MenuButton from "./components/menuButton";
// import SwipeableViews from 'react-swipeable-views';
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Hidden from "@material-ui/core/Hidden";
import MenuIcon from '@material-ui/icons/Menu';
import Drawer from '@material-ui/core/Drawer';

import Email from "@material-ui/icons/Email";
// import CheckIcon from '@material-ui/icons/Check';
const Styles = (theme) => ({
  textInput: {},
  containerAlign: {
    margin: "auto",
    maxWidth: "1180px",
  },
  appbarmob: {
    backgroundColor: "#fff",
    color:"#767676",
    "& img": {
      maxWidth: "100px",
    },
    "& div":{
      justifyContent: "space-between",
    }
  },
  appBar: {
    backgroundColor: "#fff",
    // position:"fixed",
    "& .leftGrid": {
      color: "#767676",
      "& .logo": {
        maxHeight: "40px",
      },
      "& .alignment": {
        margin: "0px",
        padding: "0px",
        listStyle: "none",
        display: "flex",
        justifyContent: "space-around",
        alignItems: "center",
        minHeight: "100%",
        fontWeight: "500",
        fontFamily: "16px LetteraTextLL",
      },
    },
    "& .rightGrid": {
      justifyContent: "flex-end",
      "& .alignment": {
        margin: "0",
        padding: "0",
        listStyle: "none",
        display: "flex",
        "& li": {
          margin: "0px 10px 0px 10px",
          "& .loginbtn": {
            border: "1px solid #4643ee",
            fontSize: "1rem",
            borderOpacity: "1",
            backgroundColor: "#fff",
            color: "#4643ee",
            width: "7.5rem",
            height: "2.5rem",
            borderRadius: "10px",
            textTransform: "none",
            fontWeight: "700",
            fontFamily: "LetteraTextLL",
          },
          "& .signupbtn": {
            border: "1px solid #4643ee",
            fontSize: "1rem",
            borderOpacity: "1",
            backgroundColor: "#4643ee",
            color: "#fff",
            width: "7.5rem",
            height: "2.5rem",
            borderRadius: "10px",
            textTransform: "none",
            fontWeight: "700",
            fontFamily: "LetteraTextLL",
          },
        },
      },
    },
  },

  section1: {
    marginTop: "80px",
    "& .banner": {
      maxWidth: "30rem",
    },
    "& .flagBox": {
      "& img": {
        maxHeight: "20px",
      },
      [theme.breakpoints.down("md")]: {
        alignSelf: "center",
      },
    },
    "& .box1": {
      fontFamily: "TiemposHeadline",
      fontWeight: "700",
      textOpacity: "1",
      fontSize: "4rem",
      lineHeight: "1.11",
      [theme.breakpoints.down("md")]: {
        textAlign: "center",
        fontSize: "2rem",
      },
    },
    "& .box2": {
      color: "#767676",
      fontSize: "1.5rem",
      fontFamily: " LetteraTextLL",
      fontWeight: "100",
      lineHeight: "1.5",
      [theme.breakpoints.down("md")]: {
        textAlign: "center",
      },
    },
    "& .flag": {
      fontFamily: "16px LetteraTextLL",
      color: "#767676",
      fontWeight: "500",
      lineHeight: "1.5",
      fontSize: "1rem",
    },
    "& .mailholder": {
      padding: "15px",
      border: "1px solid #ccc",
      borderRadius: "10px",
      color: "#ccc",
      "& .joinbtn": {
        border: "1px solid #4643ee",
        fontSize: "1rem",
        borderOpacity: "1",
        backgroundColor: "#4643ee",
        color: "#fff",
        width: "7.5rem",
        height: "2.5rem",
        borderRadius: "10px",
        textTransform: "none",
        fontWeight: "700",
        fontFamily: "LetteraTextLL",
      },
      // display: "flex",
      // "& ul": {
      //   margin: "0",
      //   padding: "0",
      //   listStyle: "none",
      //   display: "flex",
      // },
    },
  },
  section2: {
    marginTop: "50px",
    marginBottom: "100px",
    "& img": {
      maxHeight: "50px",
    },
    "& .sec2": {
      fontFamily: " LetteraTextLL",
      color: "#373737",
      fontWeight: "500",
      fontSize: "1.125rem",
      lineHeight: "1.44",
      letterSpacing: "0.45rem",
      textAlign: "center",
      marginBottom: "20px",
    },
    "& .company-logo": {
      display: "flex",
      justifyContent: "center",
    },
  },
  section3: {
    marginTop: "50px",
    "& .rightGrid": {
      "& img": {
        maxWidth: "100%",
      },
    },
    "& .sec3box1": {
      fontFamily: "LetteraTextLL",
      lineHeight: "1.33",
      color: "#4643ee",
      fontSize: "1.5rem",
      fontWeight: "700",
      textOpacity: "1",
      letterSpacing: "0",
    },
    "& .sec3box2": {
      fontSize: "3rem",
      lineHeight: "1.17",
      fontWeight: "500",
      fontFamily: "TiemposHeadline",
      letterSpacing: "0",
      textOpacity: "1",
    },
    "& .sec3box3": {
      fontSize: "1.125rem",
      lineHeight: "1.77",
      fontWeight: "400",
      fontFamily: "LetteraTextLLe",
      letterSpacing: "0",
      textOpacity: "1",
      color: "#767676",
    },
  },
  section4: {
    marginBottom: "100px",
    "& .sec4box1": {
      fontSize: "3rem",
      lineHeight: "1.17",
      fontWeight: "700",
      fontFamily: "TiemposHeadline",
    },
    "& .sec4box2": {
      fontSize: "1.5rem",
      lineHeight: "1.5",
      fontWeight: "400",
      fontFamily: "LetteraTextLL",
      color: "#767676",
      textAlign: "center",
    },
  },
  CardStyle: {
    overflow: "initial",
    // padding: "20px",
    borderRadius: "10px",
    "& .imgsection": {
      backgroundColor: "#c2f6e3",
      borderRadius: "10px 10px 0px 0px",
    },
    "& .firstsection": {
      backgroundColor: "#c2f6e3",
    },

    "& .card1": {
      maxHeight: "150px",
      marginTop: "-50px",
    },
    "& .percent": {
      "& p": {
        fontSize: "3rem",
        fontWeight: 900,
        color: "#4643ee",
      },
    },
    "& .cashBack": {
      "& span": {
        fontWeight: "700",
        borderRadius: "5px",
        backgroundColor: "#00a86b",
        padding: "0px 5px 0px 5px",
        margin: "0px 5px 0px 5px",
        color: "#fff",
      },
    },
    "& .progressbar": {
      minHeight: "10px",
      borderRadius: "5px",
      backgroundColor: "#eee",
      "& div": {
        backgroundImage: "linear-gradient(180deg,#00db8c,#00a86b)",
      },
    },
    "& .cardlist": {
      listStyle: "none",
      margin: "0",
      padding: "0",
      fontWeight: "600",
      fontSize: "1rem",
      fontFamily: "LetteraTextLL",
      textAlign: "left",
      alignSelf: "center",
      "& li": {
        padding: "10px 0px 10px 0px",
      },
    },
    "& .listtext": {
      fontWeight: "500",
      fontSize: "0.875rem",
      fontFamily: "LetteraTextLL",
      color: "#767676",
    },
    "& .lastsection": {
      backgroundColor: "#c2f6e3",
      borderRadius: "0px 0px 10px 10px",
    },
    "& .spots-left1": {
      color: "#767676",
      fontWeight: "400",
      fontSize: "0.875rem",
      "& span": {
        color: "#00a86b",
        fontSize: "1.25rem",
        fontWeight: "700",
      },
    },
    "& .spots-left2": {
      color: "#767676",
      fontWeight: "400",
      fontSize: "0.75rem",
    },
    "& .signup": {
      border: "1px solid #4643ee",
      padding: "10px",
      fontSize: "1.25rem",
      textAlign: "center",
      borderOpacity: "1",
      backgroundColor: "#4643ee",
      color: "#fff",
      width: "100%",
      height: "3.75rem",
      borderRadius: "10px",
      textTransform: "none",
      fontWeight: "700",
      fontFamily: "LetteraTextLL",
    },
  },
});

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`full-width-tabpanel-${index}`}
      aria-labelledby={`full-width-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

class homePage extends React.Component {
  constructor(props) {
    super(props);
    this.card1text = [
      "Charcoal Black Metal Card",
      "2.15%1 Bonus Rate Checking Account",
      "5% Cash back on brands you love",
      "Free Cash Withdrawals",
      "Phone & Chat Support",
    ];
    this.card2text = [
      "Free Debit Card",
      "1.65%2 Bonus Rate Checking Account",
      "4% Cash back on brands you love",
      "Free Cash Withdrawals",
      "Phone & Chat Support",
    ];
    this.card3text = [
      "Free Debit Card",
      "1.15%3 Bonus Rate Checking Account",
      "3% Cash back on brands you love",
      "Free Cash Withdrawals",
      "Phone & Chat Support",
    ];

    this.state = {
      value: 0,
      sideBarOpen:false
    };
  }

  toggleDrawer = (open) => (event) => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    this.setState({
      sideBarOpen: open,
    });
  };

  openSideBar = () => {
    this.setState({
      sideBarOpen: true,
    });
  };

  handleChange = (event, newValue) => {
    this.setState({
      value: newValue,
    });
  };

  handleChangeIndex = (index) => {
    this.setState({
      value: index,
    });
  };

  render() {
    const { classes } = this.props;
    return (
      <div>
        <Hidden mdUp>
          <AppBar position="fixed" className={classes.appbarmob}>
            <Toolbar>
            <img src={logo}  />
            <MenuIcon onClick={this.openSideBar} />
            </Toolbar>
          </AppBar>
        </Hidden>

        <Hidden mdDown>
          <AppBar position="fixed" className={classes.appBar}>
            <Toolbar>
              <Container className={classes.containerAlign}>
                <Grid container>
                  <Grid item container md={6} className="leftGrid">
                    <Grid item md={4}>
                      <img src={logo} className="logo" />
                    </Grid>
                    <Grid item md={8}>
                      <ul className="alignment">
                        <li>Home</li>

                        <li>
                          <MenuButton
                            text="Company"
                            items={["About", "Newsroom", "Careers", "Partners"]}
                          />
                        </li>

                        <li>
                          <MenuButton
                            text="Learn"
                            items={["Blog", "Guides", "Help Center"]}
                          />
                        </li>

                        <li>
                          <MenuButton
                            text="Legal"
                            items={[
                              "Privacy Policy",
                              "Terms of use",
                              "Trademarks",
                            ]}
                          />
                        </li>
                      </ul>
                    </Grid>
                  </Grid>
                  <Grid item container md={6} className="rightGrid">
                    <ul className="alignment">
                      <li>
                        <Button className="loginbtn">Login</Button>
                      </li>

                      <li>
                        <Button className="signupbtn">Signup</Button>
                      </li>
                    </ul>

                    <div></div>
                  </Grid>
                </Grid>
              </Container>
            </Toolbar>
          </AppBar>
        </Hidden>

        <Container className={classes.containerAlign}>
          <Grid container className={classes.section1}>
            <Grid item md={6}>
              <Box
                display="flex"
                flexDirection="column"
                alignItems="center"
                justifyContent="center"
              >
                <Box mb={2}>
                  <Typography className="box1">
                    The Most Powerful Checking Account
                  </Typography>
                </Box>
                <Box mb={2}>
                  <Typography className="box2">
                    Our checking account gives you higher returns than a savings
                    account with no hidden fees.
                  </Typography>
                </Box>
                <Box mb={2} width={1} display="flex" className="mailholder">
                  <Box mr={2} alignSelf="center">
                    <Email />
                  </Box>
                  <Box flexGrow={1} alignSelf="center">
                    <TextField
                      id="input-with-icon-textfield"
                      placeholder="Enter Email Address"
                      InputProps={{
                        classes: { input: classes.textInput },
                        disableUnderline: true,
                      }}
                    />
                  </Box>
                  <Box>
                    <Button className="joinbtn">Join</Button>
                  </Box>
                  {/* <div className="mailholder">
                    <ul>
                      <li>SendIcon</li>
                      <li>
                        <TextField
                          id="input-with-icon-textfield"
                          placeholder="Enter Email Address"
                          InputProps={{
                            classes: { input: classes.textInput },
                            disableUnderline: true,
                          }}
                        />
                      </li>
                      <li>
                        <Button className="signupbtn">Signup</Button>
                      </li>
                    </ul>
                  </div> */}
                </Box>
                <Box mb={2} display="flex" alignSelf="end" className="flagBox">
                  <Box mr={2}>
                    <img src={flag} />
                  </Box>
                  <Box>
                    <Typography className="flag">
                      281 spots left for Priority Access
                    </Typography>
                  </Box>
                </Box>
              </Box>
            </Grid>
            <Grid item md={6}>
              <img src={banner} className="banner" />
            </Grid>
          </Grid>
          {/* <Grid container className={classes.section2}>
            <Grid item md={12}>
              <Typography className="sec2">BACKED BY THE BEST</Typography>
            </Grid>
            <Grid item md={4} className="company-logo">
              <img src={img1} />
            </Grid>
            <Grid item md={4} className="company-logo">
              <img src={img2} />
            </Grid>
            <Grid item md={4} className="company-logo">
              <img src={img3} />
            </Grid>
          </Grid> */}
          <Grid container className={classes.section3}>
            <Grid item md={7}>
              <Box
                display="flex"
                flexDirection="column"
                alignItems="center"
                justifyContent="center"
              >
                <Box alignSelf="end" mb={2}>
                  <Typography className="sec3box1">
                    Start saving for a rainy day fund
                  </Typography>
                </Box>
                <Box mb={2}>
                  <Typography className="sec3box2">
                    Use Our Checking Account to Achieve Your Financial Goals
                  </Typography>
                </Box>
                <Box mb={2}>
                  <Typography className="sec3box3">
                    With the latest Federal rate cut, the largest banks are
                    offering close to 0% APY on their checking and savings
                    accounts. OnJuno checking will earn you more than 20x the
                    national average*. Deposits up to $250,000 are FDIC insured
                    through our partner bank. Grow your idle money faster with
                    our checking account and start saving towards a rainy day
                    fund, big expense, or vacation.
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item md={5} className="rightGrid">
              <img src={bonus} />
            </Grid>
          </Grid>
          <Grid container className={classes.section4}>
            <Box
              display="flex"
              flexDirection="column"
              alignItems="center"
              justifyContent="center"
              width={1}
            >
              <Box mb={2}>
                <Typography className="sec4box1">
                  Sign up early to save more
                </Typography>
              </Box>
              <Box width={1 / 2}>
                <Typography className="sec4box2">
                  Depending on the level of your checking account, you’ll earn
                  between 1.15%3 to 2.15%1 bonus rate.
                </Typography>
              </Box>
            </Box>
          </Grid>
          {/* <Grid container spacing={3}> */}
          <Tabs
            value={this.state.value}
            onChange={this.handleChange}
            indicatorColor="primary"
            textColor="primary"
            variant="fullWidth"
            aria-label="full width tabs example"
          >
            <Tab label="Item One" />
            <Tab label="Item Two" />
            <Tab label="Item Three" />
          </Tabs>

          {/* <SwipeableViews
              // axis={theme.direction === "rtl" ? "x-reverse" : "x"}
              index={this.state.value}
              onChangeIndex={this.handleChangeIndex}
            > */}
          <TabPanel
            value={this.state.value}
            index={0}
            // dir={theme.direction}
          >
            <Card
              cardNo="1"
              cardName="METAL"
              percent="2.15%"
              cashback="5%"
              btntext="Sign Up Now"
              cardText={this.card1text}
              minDep="1000"
              addFee="3"
              buttonText="SignUp Now"
              buttonDisabled={false}
              line1="$11.99/m"
              line2="Free for 6 months"
              line3="-$72 Savings"
            />
          </TabPanel>
          <TabPanel
            value={this.state.value}
            index={1}
            // dir={theme.direction}
          >
            <Card
              cardNo="2"
              cardName="PREMIUM"
              percent="1.67%"
              cardText={this.card2text}
              minDep="500"
              addFee="2"
              buttonText="Up Next"
              buttonDisabled={true}
              line1="$6.99/m"
              line2="Coming Soon"
              spots="2000"
            />
          </TabPanel>
          <TabPanel
            value={this.state.value}
            index={2}
            // dir={theme.direction}
          >
            <Card
              cardNo="3"
              cardName="BASIC"
              percent="1.15%"
              cardText={this.card3text}
              minDep="0"
              addFee="No"
              buttonText="Coming Soon"
              buttonDisabled={true}
              line1="No"
              line2="Free forever"
              spots="10000"
            />
          </TabPanel>
          {/* </SwipeableViews> */}
          {/* <Grid item md={4}>
              <Card
                cardNo="1"
                cardName="METAL"
                percent="2.15%"
                cashback="5%"
                btntext="Sign Up Now"
                cardText={this.card1text}
                minDep="1000"
                addFee="3"
                buttonText="SignUp Now"
                buttonDisabled={false}
                line1="$11.99/m"
                line2="Free for 6 months"
                line3="-$72 Savings"
              />
            </Grid>

            <Grid item md={4}>
              <Card
                cardNo="2"
                cardName="PREMIUM"
                percent="1.67%"
                cardText={this.card2text}
                minDep="500"
                addFee="2"
                buttonText="Up Next"
                buttonDisabled={true}
                line1="$6.99/m"
                line2="Coming Soon"
                spots="2000"
              />
            </Grid>

            <Grid item md={4}>
              <Card
                cardNo="3"
                cardName="BASIC"
                percent="1.15%"
                cardText={this.card3text}
                minDep="0"
                addFee="No"
                buttonText="Coming Soon"
                buttonDisabled={true}
                line1="No"
                line2="Free forever"
                spots="10000"
              />
            </Grid> */}
          {/* </Grid> */}
        </Container>

        <Drawer
          // anchor={anchor}
          open={this.state.sideBarOpen}
          onClose={this.toggleDrawer(false)}
          onOpen={this.toggleDrawer(true)}
        >
          {/* <div className={classes.drawerDiv}>
            <List
              component="nav"
              aria-labelledby="nested-list-subheader"
              subheader={
                <ListItem className="justify-end">
                <CloseIcon  onClick={this.toggleDrawer(false)}/>
              </ListItem>
              }
              // onClick={this.toggleDrawer( false)}
              // onKeyDown={this.toggleDrawer(false)}
              // className={classes.root}
            >
             

              <ListItem button onClick={this.handleCompanyClick}>
                <ListItemText primary="COMPANY" />
                {this.state.companyOpen ? <ExpandLess /> : <ExpandMore />}
              </ListItem>
              <Collapse
                in={this.state.companyOpen}
                timeout="auto"
                unmountOnExit
              >
                <List component="div" disablePadding>
                  <ListItem button>
                    <a
                      className="pl-4 text-gray-500"
                      href="https://cloudwiry.com/about"
                    >
                      About
                    </a>
                  </ListItem>
                  <ListItem button>
                    <a
                      className="pl-4 text-gray-500"
                      href="https://cloudwiry.com/careers"
                    >
                      Careers
                    </a>
                  </ListItem>
                  <ListItem button>
                    <a
                      className="pl-4 text-gray-500"
                      href="https://cloudwiry.com/press"
                    >
                      Press
                    </a>
                  </ListItem>
                </List>
              </Collapse>
              <ListItem button>
                <ListItemText primary="SOLUTIONS" />
              </ListItem>
              <ListItem button onClick={this.handleResourceClick}>
                <ListItemText primary="RESOURCES" />
                {this.state.resourceOpen ? <ExpandLess /> : <ExpandMore />}
              </ListItem>
              <Collapse
                in={this.state.resourceOpen}
                timeout="auto"
                unmountOnExit
              >
                <List component="div" disablePadding>
                  <ListItem button>
                    <a
                      className="pl-4 text-gray-500"
                      href="https://cloudwiry.com/blogs"
                    >
                      Blogs
                    </a>
                  </ListItem>
                  <ListItem button>
                    <a
                      className="pl-4 text-gray-500"
                      href="https://cloudwiry.com/case-studies/"
                    >
                      Case Studies
                    </a>
                  </ListItem>
                  <ListItem button>
                    <a
                      className="pl-4 text-gray-500"
                      href="https://cloudwiry.com/webinars"
                    >
                      Webinars
                    </a>
                  </ListItem>
                  <ListItem button>
                    <a
                      className="pl-4 text-gray-500"
                      href="https://cloudwiry.com/videos"
                    >
                      Videos
                    </a>
                  </ListItem>
                  <ListItem button>
                    <a
                      className="pl-4 text-gray-500"
                      href="https://cloudwiry.com/faq"
                    >
                      FAQs
                    </a>
                  </ListItem>
                </List>
              </Collapse>
            </List>
          </div> */}
        </Drawer>
      </div>
    );
  }
}

export default withStyles(Styles)(homePage);
// export default (homePage);
